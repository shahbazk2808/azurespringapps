package com.example.spring.azspring;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AzspringApplicationTests {

	/*
	 * @Test void contextLoads() { }
	 */

}
